import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-personal',
  templateUrl: './main-personal.component.html'
})
export class MainPersonalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
