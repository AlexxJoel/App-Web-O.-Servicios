//{} destructuración
const { personalRouter } = require('./personal/personal.controller');

module.exports = {
    personalRouter,
}